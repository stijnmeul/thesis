clear
rm node.xpi ; zip -x build.sh -r node.xpi *
date
