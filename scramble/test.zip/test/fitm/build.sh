clear
rm fitm.xpi ; zip -x build.sh -r fitm.xpi *
date
