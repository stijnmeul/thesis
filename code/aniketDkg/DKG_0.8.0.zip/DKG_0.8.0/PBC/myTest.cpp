#include <iostream>
//#include "G1.h"
//#include "G2.h"
//#include "G.h"
//#include "GT.h"
//#include "Pairing.h"
//#include "PBCExceptions.h"
//#include "PPPairing.h"
//#include "Zr.h"

using namespace std;

//extern "C" {
//#include <pbc/pbc.h>
//}
#include <pbc/pbc.h>

int main(int argc, char **argv)
{

  pairing_t test;
  return 0;
}
