#include <iostream>
#include "stijnspower.h"

using namespace std;
 
int main() {
   cout << "Hello, world!" << endl;
   cout << power(2.0, 2);
   return 0;
}
